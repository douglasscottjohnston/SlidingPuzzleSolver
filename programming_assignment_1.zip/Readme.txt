SIZE: 4
INITIAL STATE:
[['1' '2' '3' '4']
 ['5' '6' '7' '8']
 ['9' 'A' 'B' 'C']
 ['D' 'F' 'E' ' ']]
GOAL STATE:
[['1' '2' '3' '4']
 ['5' '6' '7' '8']
 ['9' 'A' 'B' 'C']
 ['D' 'E' 'F' ' ']]
SEARCH METHOD:
bfs
DEPTH: -1, NUM CREATED: 0, NUM EXPANDED: 0, MAX FRINGE: 0
SIZE: 4
INITIAL STATE:
[['1' '2' '3' '4']
 ['5' '6' '7' '8']
 ['9' 'A' 'B' 'C']
 ['D' ' ' 'E' 'F']]
GOAL STATE:
[['1' '2' '3' '4']
 ['5' '6' '7' '8']
 ['9' 'A' 'B' 'C']
 ['D' 'E' 'F' ' ']]
SEARCH METHOD:
bfs
DEPTH: 2, NUM CREATED: 30, NUM EXPANDED: 9, MAX FRINGE: 14
SIZE: 6
INITIAL STATE:
[['1' '2' '3' '4' '5' '6']
 ['7' '8' '9' 'A' 'B' 'C']
 ['D' 'E' 'F' 'G' 'H' 'I']
 ['J' 'K' 'L' 'M' 'N' 'O']
 ['P' 'Q' 'R' 'S' 'T' 'U']
 ['V' 'W' ' ' 'X' 'Y' 'Z']]
GOAL STATE:
[['1' '2' '3' '4' '5' '6']
 ['7' '8' '9' 'A' 'B' 'C']
 ['D' 'E' 'F' 'G' 'H' 'I']
 ['J' 'K' 'L' 'M' 'N' 'O']
 ['P' 'Q' 'R' 'S' 'T' 'U']
 ['V' 'W' 'X' 'Y' 'Z' ' ']]
SEARCH METHOD:
bfs
DEPTH: 3, NUM CREATED: 101, NUM EXPANDED: 28, MAX FRINGE: 47
SIZE: 6
INITIAL STATE:
[['2' '1' '3' '4' '5' '6']
 ['7' '8' '9' 'A' 'B' 'C']
 ['D' 'E' 'F' 'G' 'H' 'I']
 ['J' 'K' 'L' 'M' 'N' 'O']
 ['P' 'Q' 'R' 'S' 'T' 'U']
 ['V' 'W' ' ' 'X' 'Y' 'Z']]
GOAL STATE:
[['1' '2' '3' '4' '5' '6']
 ['7' '8' '9' 'A' 'B' 'C']
 ['D' 'E' 'F' 'G' 'H' 'I']
 ['J' 'K' 'L' 'M' 'N' 'O']
 ['P' 'Q' 'R' 'S' 'T' 'U']
 ['V' 'W' 'X' 'Y' 'Z' ' ']]
SEARCH METHOD:
bfs
DEPTH: -1, NUM CREATED: 0, NUM EXPANDED: 0, MAX FRINGE: 0
SIZE: 6
INITIAL STATE:
[['2' '1' '4' '3' '5' '6']
 ['7' '8' '9' 'A' 'B' 'C']
 ['D' 'E' 'F' 'G' 'H' 'I']
 ['J' 'K' 'L' 'M' 'N' 'O']
 ['P' 'Q' 'R' 'S' 'T' 'U']
 ['V' 'W' ' ' 'X' 'Y' 'Z']]
GOAL STATE:
[['1' '2' '3' '4' '5' '6']
 ['7' '8' '9' 'A' 'B' 'C']
 ['D' 'E' 'F' 'G' 'H' 'I']
 ['J' 'K' 'L' 'M' 'N' 'O']
 ['P' 'Q' 'R' 'S' 'T' 'U']
 ['V' 'W' 'X' 'Y' 'Z' ' ']]
SEARCH METHOD:
bfs
DEPTH: -1, NUM CREATED: 0, NUM EXPANDED: 0, MAX FRINGE: 0
SIZE: 6
INITIAL STATE:
[['2' '1' '4' '3' ' ' '5']
 ['6' '7' '8' '9' 'A' 'B']
 ['C' 'D' 'E' 'F' 'G' 'H']
 ['I' 'J' 'K' 'L' 'M' 'N']
 ['O' 'P' 'Q' 'R' 'S' 'T']
 ['U' 'V' 'W' 'X' 'Y' 'Z']]
GOAL STATE:
[['1' '2' '3' '4' '5' '6']
 ['7' '8' '9' 'A' 'B' 'C']
 ['D' 'E' 'F' 'G' 'H' 'I']
 ['J' 'K' 'L' 'M' 'N' 'O']
 ['P' 'Q' 'R' 'S' 'T' 'U']
 ['V' 'W' 'X' 'Y' 'Z' ' ']]
SEARCH METHOD:
bfs
DEPTH: -1, NUM CREATED: 0, NUM EXPANDED: 0, MAX FRINGE: 0